public class operacionesEstadisticas implements estadisticas {
    private datos datos;

    @Override
    public double calcularDesviacionEstandar(double[] list) {
        double promedio = calcularPromedio(list);
        double suma = 0;
        for (double n : list) {
            suma += Math.pow(n - promedio, 2);
        }
        return Math.sqrt(suma / list.length);
    }

    @Override
    public double calcularModa(double[] list) {
        double moda = list[0];
        int maxCount = 0;
        for (int i = 0; i < list.length; i++) {
            int count = 0;
            for (int j = 0; j < list.length; j++) {
                if (list[j] == list[i]) count++;
            }
            if (count > maxCount) {
                maxCount = count;
                moda = list[i];
            }
        }
        return moda;
    }

    @Override
    public double calcularPromedio(double[] list) {
        double suma = 0;
        for (double n : list) {
            suma += n;
        }
        return suma / list.length;
    }

    public double[] obtenerNumeros() {
        if (datos != null) {
            return datos.getNumeros();
        }
        return null;
    }

    public void setDatos(datos datos) {
        this.datos = datos;
    }
}
