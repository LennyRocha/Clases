public class generadorInforme {
    public void generar(estadisticas e, double[] list) {
        System.out.println("--- Informe Estadístico ---");
        System.out.println("Promedio: " + e.calcularPromedio(list));
        System.out.println("Desviación estándar: " + e.calcularDesviacionEstandar(list));
        System.out.println("Moda: " + e.calcularModa(list));
    }
}