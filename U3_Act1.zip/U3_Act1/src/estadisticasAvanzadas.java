import java.util.Arrays;

public class estadisticasAvanzadas extends operacionesEstadisticas {

    // Coeficiente de variación = (Desviación estándar / Media) * 100
    public double calcularCoeficienteDeVariacion(double[] num) {
        double media = calcularMedia(num);
        double desviacionEstandar = calcularDesviacionEstandar(num);
        return (desviacionEstandar / media) * 100;
    }

    // Mediana: valor central del conjunto ordenado
    public double calcularMediana(double[] num) {
        double[] copia = Arrays.copyOf(num, num.length);
        Arrays.sort(copia);
        int n = copia.length;
        if (n % 2 == 0) {
            // Si es par: promedio de los dos del centro
            return (copia[n / 2 - 1] + copia[n / 2]) / 2.0;
        } else {
            // Si es impar: el del centro
            return copia[n / 2];
        }
    }

    // Percentil: posición = (percentil / 100) * (n - 1)
    public double calcularPercentil(double[] num, double percentil) {
        double[] copia = Arrays.copyOf(num, num.length);
        Arrays.sort(copia);
        if (percentil < 0 || percentil > 100)
            throw new IllegalArgumentException("El percentil debe estar entre 0 y 100");
        double posicion = (percentil / 100.0) * (copia.length - 1);
        int indiceInferior = (int) Math.floor(posicion);
        int indiceSuperior = (int) Math.ceil(posicion);
        if (indiceInferior == indiceSuperior) {
            return copia[indiceInferior];
        } else {
            // Interpolación lineal
            double peso = posicion - indiceInferior;
            return copia[indiceInferior] + peso * (copia[indiceSuperior] - copia[indiceInferior]);
        }
    }

    // Rango = valor máximo - valor mínimo
    public double calcularRango(double[] num) {
        double min = Arrays.stream(num).min().orElse(Double.NaN);
        double max = Arrays.stream(num).max().orElse(Double.NaN);
        return max - min;
    }

    // Varianza: promedio de los cuadrados de las diferencias respecto a la media
    public double calcularVarianza(double[] num) {
        double media = calcularMedia(num);
        double suma = 0;
        for (double n : num) {
            suma += Math.pow(n - media, 2);
        }
        return suma / num.length; // Varianza poblacional
    }

    // Si tu clase base no tiene estos, puedes incluirlos:
    public double calcularMedia(double[] num) {
        double suma = 0;
        for (double n : num) {
            suma += n;
        }
        return suma / num.length;
    }

    public double calcularDesviacionEstandar(double[] num) {
        return Math.sqrt(calcularVarianza(num));
    }
}