public interface estadisticas {
    double calcularDesviacionEstandar(double[] list);
    double calcularModa(double[] list);
    double calcularPromedio(double[] list);
}
