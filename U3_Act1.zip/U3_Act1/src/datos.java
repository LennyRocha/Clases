public class datos {
    private double[] numeros;

    public datos(double[] numeros) {
        this.numeros = numeros;
    }

    public double[] getNumeros() {
        return numeros;
    }
}
